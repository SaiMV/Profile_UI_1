import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-educational-details-selection-box',
  templateUrl: './educational-details-selection-box.component.html',
  styleUrls: ['./educational-details-selection-box.component.scss']
})
export class EducationalDetailsSelectionBoxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
