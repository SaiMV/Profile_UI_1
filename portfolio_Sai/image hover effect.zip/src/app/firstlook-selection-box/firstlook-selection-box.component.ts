import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-firstlook-selection-box',
  templateUrl: './firstlook-selection-box.component.html',
  styleUrls: ['./firstlook-selection-box.component.scss']
})
export class FirstlookSelectionBoxComponent implements OnInit {
  heasdrer1: String = "";
  subHeader:String = "";
  constructor() { }
  currentClassName:String='';
  ngOnInit() {
    this.heasdrer1 = "I'm Sai, a front end web developer";
    this.subHeader="Full Stack - Apps - Web";
      setInterval(()=> {
          if(this.currentClassName === 'is-loading'){
              console.log(this.currentClassName);
              this.currentClassName = '';
          }else{
              this.currentClassName='is-loading';
          }
      }, 3000);

  }

}
