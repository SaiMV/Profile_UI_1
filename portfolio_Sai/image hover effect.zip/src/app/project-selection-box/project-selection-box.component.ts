import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-selection-box',
  templateUrl: './project-selection-box.component.html',
  styleUrls: ['./project-selection-box.component.scss']
})
export class ProjectSelectionBoxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  menuClicked:boolean = false;
    toggleClass(){
          this.menuClicked = !this.menuClicked;
    }
}
