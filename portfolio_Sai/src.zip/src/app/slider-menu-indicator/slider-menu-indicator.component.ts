import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-slider-menu-indicator',
  templateUrl: './slider-menu-indicator.component.html',
  styleUrls: ['./slider-menu-indicator.component.scss']
})
export class SliderMenuIndicatorComponent implements OnInit {

  constructor(public router: Router) {

  }

  starterViewIndex = 0;
  slides: any[] =  [];

  ngOnInit() {
 this.slides = ['firstLook' , 'aboutMe' , 'personalDetails', 'mySkills' , 'myProjects' , 'getInTouchwith' ,'educationalDetails'];

  }
    menuClicked:boolean = false;
    toggleClass(){
        this.menuClicked = !this.menuClicked;
    }
  gotoView(sliders, index) {
    this.starterViewIndex = index;
    this.router.navigate([sliders]);
  }
  gotoNextView() {
    this.starterViewIndex = this.starterViewIndex + 1;
    if ( this.starterViewIndex > (this.slides.length - 1)) {
      this.starterViewIndex = 0;
    }
    this.router.navigate([this.slides[this.starterViewIndex]]);
    // this.router.ac
  }

  gotoPreviousView() {

    this.starterViewIndex = this.starterViewIndex - 1;
    if ( this.starterViewIndex < 0) {
      this.starterViewIndex = this.slides.length - 1;
    }
    this.router.navigate([this.slides[this.starterViewIndex]]);
    // this.router.ac
  }
getInTouchWith() {
    this.router.navigate(['getInTouchwith' ]);

}

    gotoMyProjects() {
        this.router.navigate(['myProjects' ]);

    }
    gotoFirstLook() {
        this.router.navigate(['firstLook' ]);

    }
    gotoPersonalDetails() {
        this.router.navigate(['personalDetails' ]);

    }
    gotoAboutMe() {
        this.router.navigate(['aboutMe' ]);

    }
}
