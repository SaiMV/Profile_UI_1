import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-experience-selection-box',
  templateUrl: './experience-selection-box.component.html',
  styleUrls: ['./experience-selection-box.component.scss']
})
export class ExperienceSelectionBoxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
